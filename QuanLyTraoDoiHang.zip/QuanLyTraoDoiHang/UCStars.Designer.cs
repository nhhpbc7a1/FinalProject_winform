﻿namespace QuanLyTraoDoiHang
{
    partial class UCStars
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCStars));
            this.comboBoxNum = new System.Windows.Forms.ComboBox();
            this.picStar4 = new System.Windows.Forms.PictureBox();
            this.picStar3 = new System.Windows.Forms.PictureBox();
            this.picStar2 = new System.Windows.Forms.PictureBox();
            this.picStar1 = new System.Windows.Forms.PictureBox();
            this.pnlRating = new System.Windows.Forms.FlowLayoutPanel();
            this.picStar5 = new System.Windows.Forms.PictureBox();
            this.lblNumStar = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.picStar4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStar3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStar2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStar1)).BeginInit();
            this.pnlRating.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picStar5)).BeginInit();
            this.SuspendLayout();
            // 
            // comboBoxNum
            // 
            this.comboBoxNum.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.comboBoxNum.DropDownWidth = 40;
            this.comboBoxNum.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.comboBoxNum.FormattingEnabled = true;
            this.comboBoxNum.Items.AddRange(new object[] {
            "1",
            "2",
            "3",
            "4",
            "5"});
            this.comboBoxNum.Location = new System.Drawing.Point(133, 3);
            this.comboBoxNum.Name = "comboBoxNum";
            this.comboBoxNum.Size = new System.Drawing.Size(40, 29);
            this.comboBoxNum.TabIndex = 8;
            // 
            // picStar4
            // 
            this.picStar4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picStar4.BackgroundImage")));
            this.picStar4.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picStar4.Location = new System.Drawing.Point(66, 10);
            this.picStar4.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.picStar4.Name = "picStar4";
            this.picStar4.Size = new System.Drawing.Size(15, 15);
            this.picStar4.TabIndex = 6;
            this.picStar4.TabStop = false;
            // 
            // picStar3
            // 
            this.picStar3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picStar3.BackgroundImage")));
            this.picStar3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picStar3.Location = new System.Drawing.Point(45, 10);
            this.picStar3.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.picStar3.Name = "picStar3";
            this.picStar3.Size = new System.Drawing.Size(15, 15);
            this.picStar3.TabIndex = 6;
            this.picStar3.TabStop = false;
            // 
            // picStar2
            // 
            this.picStar2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picStar2.BackgroundImage")));
            this.picStar2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picStar2.Location = new System.Drawing.Point(24, 10);
            this.picStar2.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.picStar2.Name = "picStar2";
            this.picStar2.Size = new System.Drawing.Size(15, 15);
            this.picStar2.TabIndex = 5;
            this.picStar2.TabStop = false;
            // 
            // picStar1
            // 
            this.picStar1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picStar1.BackgroundImage")));
            this.picStar1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picStar1.Location = new System.Drawing.Point(3, 10);
            this.picStar1.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.picStar1.Name = "picStar1";
            this.picStar1.Size = new System.Drawing.Size(15, 15);
            this.picStar1.TabIndex = 1;
            this.picStar1.TabStop = false;
            // 
            // pnlRating
            // 
            this.pnlRating.Controls.Add(this.picStar1);
            this.pnlRating.Controls.Add(this.picStar2);
            this.pnlRating.Controls.Add(this.picStar3);
            this.pnlRating.Controls.Add(this.picStar4);
            this.pnlRating.Controls.Add(this.picStar5);
            this.pnlRating.Controls.Add(this.lblNumStar);
            this.pnlRating.Controls.Add(this.comboBoxNum);
            this.pnlRating.Location = new System.Drawing.Point(3, 0);
            this.pnlRating.Name = "pnlRating";
            this.pnlRating.Size = new System.Drawing.Size(189, 44);
            this.pnlRating.TabIndex = 55;
            // 
            // picStar5
            // 
            this.picStar5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("picStar5.BackgroundImage")));
            this.picStar5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picStar5.Location = new System.Drawing.Point(87, 10);
            this.picStar5.Margin = new System.Windows.Forms.Padding(3, 10, 3, 3);
            this.picStar5.Name = "picStar5";
            this.picStar5.Size = new System.Drawing.Size(15, 15);
            this.picStar5.TabIndex = 6;
            this.picStar5.TabStop = false;
            // 
            // lblNumStar
            // 
            this.lblNumStar.AutoSize = true;
            this.lblNumStar.Font = new System.Drawing.Font("Segoe UI", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point);
            this.lblNumStar.Location = new System.Drawing.Point(108, 6);
            this.lblNumStar.Margin = new System.Windows.Forms.Padding(3, 6, 3, 0);
            this.lblNumStar.Name = "lblNumStar";
            this.lblNumStar.Size = new System.Drawing.Size(19, 21);
            this.lblNumStar.TabIndex = 56;
            this.lblNumStar.Text = "5";
            this.lblNumStar.Visible = false;
            // 
            // UCStars
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.pnlRating);
            this.Name = "UCStars";
            this.Size = new System.Drawing.Size(195, 44);
            ((System.ComponentModel.ISupportInitialize)(this.picStar4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStar3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStar2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picStar1)).EndInit();
            this.pnlRating.ResumeLayout(false);
            this.pnlRating.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picStar5)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion
        private PictureBox picStar4;
        private PictureBox picStar3;
        private PictureBox picStar2;
        private PictureBox picStar1;
        private FlowLayoutPanel pnlRating;
        private PictureBox picStar5;
        public ComboBox comboBoxNum;
        public Label lblNumStar;
    }
}